class Scene extends PIXI.Sprite{


	/*for now it is only sprite extension*/

	/*it should have more scene control functions*/
	constructor(parent){
		super();
	}


	/*create(parent){

	}

	removeScene(){

	}*/

}